# QUANDO A ÁGUA SOBE — Android + Login Google

Projeto Android Studio do jogo, agora preparado para **Entrar com Google usando Firebase Authentication + Credential Manager**. A integração segue a documentação oficial atual do Firebase/Android.

## O que já está pronto
- Botão **ENTRAR COM GOOGLE** na tela inicial.
- Ponte segura entre o jogo HTML e o código Android nativo.
- Google ID Token -> Firebase Authentication.
- Exibição do nome/e-mail do usuário após login.
- Logout preparado no código nativo.
- O jogo continua podendo ser jogado como convidado.

## Configuração obrigatória do Firebase
1. Crie um projeto em https://console.firebase.google.com/.
2. Adicione um app Android com o applicationId `com.quandoaguasobe.game`.
3. No Firebase Authentication, habilite o provedor **Google**.
4. Cadastre a impressão digital SHA-1 do certificado usado no teste/publicação.
5. Baixe o `google-services.json` atualizado e coloque em `app/google-services.json`.
6. Abra o projeto no Android Studio e sincronize o Gradle.
7. O plugin do Google Services deste projeto é aplicado automaticamente quando o arquivo `app/google-services.json` existe.

O Firebase recomenda usar o Android BoM para manter as bibliotecas compatíveis e, para Google Sign-In, usar Credential Manager + `googleid`.

## Web Client ID
O código tenta usar automaticamente o `default_web_client_id` gerado pelo plugin do Google Services. Se o seu projeto não gerar esse recurso, coloque o OAuth 2.0 **Web application client ID** em `app/src/main/res/values/strings.xml`, substituindo `COLOQUE_AQUI_SEU_WEB_CLIENT_ID`.

## Gerar APK
No Android Studio: **Build > Build APK(s)**.

## Publicação na Google Play
Para publicar, gere uma versão assinada em **Build > Generate Signed Bundle / APK** e prefira o formato **Android App Bundle (.aab)** para a Play Store.

## Importante
Não coloque um `google-services.json` de outra pessoa no projeto. Ele pertence ao seu projeto Firebase. O login só funcionará de verdade depois dessa configuração.
