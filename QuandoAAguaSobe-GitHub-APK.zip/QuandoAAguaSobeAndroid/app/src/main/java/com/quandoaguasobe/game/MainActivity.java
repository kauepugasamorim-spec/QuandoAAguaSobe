package com.quandoaguasobe.game;

import android.app.Activity;
import android.os.Bundle;
import android.os.CancellationSignal;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.graphics.Color;
import android.content.Context;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.credentials.Credential;
import androidx.credentials.CredentialManager;
import androidx.credentials.CredentialManagerCallback;
import androidx.credentials.CustomCredential;
import androidx.credentials.GetCredentialRequest;
import androidx.credentials.GetCredentialResponse;
import androidx.credentials.exceptions.GetCredentialException;

import com.google.android.libraries.identity.googleid.GetGoogleIdOption;
import com.google.android.libraries.identity.googleid.GoogleIdTokenCredential;
import com.google.android.libraries.identity.googleid.GoogleIdTokenParsingException;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;

import java.util.concurrent.Executors;

import static com.google.android.libraries.identity.googleid.GoogleIdTokenCredential.TYPE_GOOGLE_ID_TOKEN_CREDENTIAL;

public class MainActivity extends Activity {
    private WebView webView;
    private CredentialManager credentialManager;
    private FirebaseAuth firebaseAuth;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Color.rgb(6,19,31));
        getWindow().setNavigationBarColor(Color.rgb(6,19,31));

        credentialManager = CredentialManager.create(this);
        try { firebaseAuth = FirebaseAuth.getInstance(); }
        catch (Exception e) { Log.w("QAS_AUTH", "Firebase ainda não configurado", e); }

        webView = new WebView(this);
        webView.setBackgroundColor(Color.rgb(6,19,31));
        WebSettings s = webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setAllowContentAccess(true);
        s.setBuiltInZoomControls(false);
        s.setDisplayZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(true);
        webView.setWebViewClient(new WebViewClient());
        webView.setWebChromeClient(new WebChromeClient());
        webView.addJavascriptInterface(new GoogleBridge(this), "AndroidGoogle");
        setContentView(webView);
        webView.loadUrl("file:///android_asset/index.html");
    }

    private String getServerClientId() {
        int id = getResources().getIdentifier("default_web_client_id", "string", getPackageName());
        if (id != 0) {
            String generated = getString(id);
            if (generated != null && !generated.isEmpty()) return generated;
        }
        return getString(com.quandoaguasobe.game.R.string.server_client_id);
    }

    private void signInWithGoogle() {
        if (firebaseAuth == null) {
            sendJs("window.onGoogleLoginError('Firebase ainda não foi configurado. Coloque o google-services.json em app/ e ative o login Google no Firebase.');");
            return;
        }
        String serverClientId = getServerClientId();
        if (serverClientId.startsWith("COLOQUE_AQUI")) {
            sendJs("window.onGoogleLoginError('Falta configurar o Web Client ID do Google/Firebase.');");
            return;
        }
        GetGoogleIdOption googleIdOption = new GetGoogleIdOption.Builder()
                .setServerClientId(serverClientId)
                .setFilterByAuthorizedAccounts(false)
                .build();
        GetCredentialRequest request = new GetCredentialRequest.Builder()
                .addCredentialOption(googleIdOption)
                .build();

        credentialManager.getCredentialAsync(this, request, new CancellationSignal(), Executors.newSingleThreadExecutor(),
                new CredentialManagerCallback<GetCredentialResponse, GetCredentialException>() {
                    @Override public void onResult(@NonNull GetCredentialResponse result) {
                        handleCredential(result.getCredential());
                    }
                    @Override public void onError(@NonNull GetCredentialException e) {
                        sendJs("window.onGoogleLoginError(" + jsQuote("Não foi possível entrar com Google: " + e.getMessage()) + ");");
                    }
                });
    }

    private void handleCredential(Credential credential) {
        if (credential instanceof CustomCredential && TYPE_GOOGLE_ID_TOKEN_CREDENTIAL.equals(credential.getType())) {
            try {
                GoogleIdTokenCredential googleCredential = GoogleIdTokenCredential.createFrom(((CustomCredential) credential).getData());
                AuthCredential firebaseCredential = GoogleAuthProvider.getCredential(googleCredential.getIdToken(), null);
                firebaseAuth.signInWithCredential(firebaseCredential)
                        .addOnSuccessListener(authResult -> {
                            FirebaseUser user = firebaseAuth.getCurrentUser();
                            if (user != null) {
                                sendJs("window.onGoogleLoginSuccess(" + jsQuote(user.getDisplayName()) + "," + jsQuote(user.getEmail()) + ");");
                            }
                        })
                        .addOnFailureListener(e -> sendJs("window.onGoogleLoginError(" + jsQuote("Falha no Firebase: " + e.getMessage()) + ");"));
            } catch (GoogleIdTokenParsingException e) {
                sendJs("window.onGoogleLoginError(" + jsQuote("Não foi possível ler a credencial Google.") + ");");
            }
        } else {
            sendJs("window.onGoogleLoginError(" + jsQuote("A credencial selecionada não é uma conta Google compatível.") + ");");
        }
    }

    private void signOut() {
        if (firebaseAuth != null) firebaseAuth.signOut();
        sendJs("window.onGoogleLogout();");
    }

    private void sendJs(String code) {
        runOnUiThread(() -> { if (webView != null) webView.evaluateJavascript(code, null); });
    }

    private String jsQuote(String value) {
        if (value == null) value = "";
        return org.json.JSONObject.quote(value);
    }

    public class GoogleBridge {
        private final Context context;
        GoogleBridge(Context context) { this.context = context; }
        @JavascriptInterface public void signIn() { runOnUiThread(() -> signInWithGoogle()); }
        @JavascriptInterface public void signOut() { runOnUiThread(() -> MainActivity.this.signOut()); }
        @JavascriptInterface public String getUserEmail() {
            FirebaseUser u = firebaseAuth == null ? null : firebaseAuth.getCurrentUser();
            return u == null || u.getEmail() == null ? "" : u.getEmail();
        }
    }

    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }

    @Override protected void onDestroy() {
        if (webView != null) { webView.stopLoading(); webView.destroy(); }
        super.onDestroy();
    }
}
